# 可视化课程推荐

## 卡爾加里大學数据可视化课程

[卡爾加里大學(University of Calgary) 的信息可视化课程](https://innovis.cpsc.ucalgary.ca/Courses/CPSC683-2017)
标准的大学课程体系，理论学习为主，配合课后实践。实践主要是以 processing 应用为主。同时课程给出了可视化领域的经典参考资料。

## 斯坦福大学数据可视化课程

[斯坦福大学的可视化课程](https://magrawala.github.io/cs448b-fa17/)整体结构比较清晰。构建在平面设计、视觉艺术、知觉心理学和认知科学的基础之上。课程体系采用标准的理论+课程设计的模式。编程实践以 d3 为主要工具。

## 浙江大学

[可视化导论](http://www.icourse163.org/course/ZJU-1206452826?tid=1206781239)课程是面对当前科学可视化、信息可视化、可视分析研究和应用的新形式，开设的一门数据可视化入门课程，比较偏向理论方面的教学。

## 墨者学院

[数据可视化入门教程](https://www.yuque.com/mo-college/beginner-tutorial)。该教程不涉及可视化底层研发，介绍了可视化展现的基本原理和工具的应用（g2，f2，g6，l7）。

## 极客时间

[跟月影学可视化](https://time.geekbang.org/column/intro/100053801?code=cmin3f6%2FKc33avnFpzpH2bB6ClmEEvbS5qgj7sFZ9wE%3D)。该课程聚焦于可视化渲染引擎的开发，3d 相关内容较多。


